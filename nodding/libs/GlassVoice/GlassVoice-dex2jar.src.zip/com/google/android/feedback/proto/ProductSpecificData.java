package com.google.android.feedback.proto;

public abstract interface ProductSpecificData
{
  public static final int KEY = 1;
  public static final int TYPE = 3;
  public static final int TYPE_ENUM = 2;
  public static final int TYPE_NUMBER = 3;
  public static final int TYPE_STRING = 1;
  public static final int VALUE = 2;
}

/* Location:           /home/phil/workspace/glass_hello_world/libs/GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.ProductSpecificData
 * JD-Core Version:    0.6.2
 */