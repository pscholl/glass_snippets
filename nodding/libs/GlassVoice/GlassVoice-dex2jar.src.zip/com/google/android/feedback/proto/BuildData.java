package com.google.android.feedback.proto;

public abstract interface BuildData
{
  public static final int BOARD = 10;
  public static final int BRAND = 11;
  public static final int BUILD_FINGERPRINT = 12;
  public static final int BUILD_ID = 2;
  public static final int BUILD_TYPE = 3;
  public static final int CODENAME = 9;
  public static final int DEVICE = 1;
  public static final int INCREMENTAL = 8;
  public static final int MODEL = 4;
  public static final int PRODUCT = 5;
  public static final int RELEASE = 7;
  public static final int SDK_INT = 6;
}

/* Location:           /home/phil/workspace/glass_hello_world/libs/GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.BuildData
 * JD-Core Version:    0.6.2
 */