package com.google.android.speech.exception;

public class AudioRecognizeException extends RecognizeException
{
  private static final long serialVersionUID = 5408828137854549221L;

  public AudioRecognizeException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}

/* Location:           /home/phil/workspace/glass_hello_world/libs/GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.speech.exception.AudioRecognizeException
 * JD-Core Version:    0.6.2
 */