package com.google.android.speech.exception;

public class NoMatchRecognizeException extends RecognizeException
{
  private static final long serialVersionUID = -9051570034358940471L;
}

/* Location:           /home/phil/workspace/glass_hello_world/libs/GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.speech.exception.NoMatchRecognizeException
 * JD-Core Version:    0.6.2
 */