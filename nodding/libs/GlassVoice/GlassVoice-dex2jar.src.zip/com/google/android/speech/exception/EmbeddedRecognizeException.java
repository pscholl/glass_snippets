package com.google.android.speech.exception;

public class EmbeddedRecognizeException extends RecognizeException
{
  private static final long serialVersionUID = -1390776635774989851L;

  public EmbeddedRecognizeException(String paramString)
  {
    super(paramString);
  }

  public EmbeddedRecognizeException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}

/* Location:           /home/phil/workspace/glass_hello_world/libs/GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.speech.exception.EmbeddedRecognizeException
 * JD-Core Version:    0.6.2
 */