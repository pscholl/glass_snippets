package com.google.common.io;

public enum FileWriteMode
{
  static
  {
    FileWriteMode[] arrayOfFileWriteMode = new FileWriteMode[1];
    arrayOfFileWriteMode[0] = APPEND;
  }
}

/* Location:           /home/phil/workspace/glass_hello_world/libs/GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.common.io.FileWriteMode
 * JD-Core Version:    0.6.2
 */