package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;

@GwtCompatible(emulated=true)
abstract class ForwardingImmutableSet<E>
{
}

/* Location:           /home/phil/workspace/glass_hello_world/libs/GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.common.collect.ForwardingImmutableSet
 * JD-Core Version:    0.6.2
 */